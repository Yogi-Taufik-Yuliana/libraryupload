<!DOCTYPE html>
<html>
<head>
	<title>login</title>
</head>

<body>

<form action=""method="post">
	<input type="text"name="username"/>
	<input type="password"name="password"/>
	<input type="submit"name="login"/>
</form>

</body>
</html>